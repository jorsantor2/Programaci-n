package EjerciciosObligatorios;  // Declaración del paquete al que pertenece la clase Ejer1

public class Ejer1 {  // Declaración de la clase llamada Ejer1

    public static void main(String[] args) {  // Método principal que se ejecuta cuando se inicia el programa
        int año = 2023;  // Declaración de una variable entera llamada "año" y asignación del valor 2023

        // Impresión de un mensaje de felicitación en varias líneas utilizando la función "println" de la clase "System.out"
        System.out.println("Buenas noches. En estos días tan especiales a finales del año " + año + " en los que siempre nos deben unir\n"
                + "los mejores sentimientos os deseo, junto a la Reina y nuestras hijas, una Feliz Navidad y que en el\n"
                + "próximo año " + (año + 1) + " podáis ver cumplidos vuestros anhelos y aspiraciones");
    }
}


