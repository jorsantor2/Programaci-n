package EjerciciosObligatorios;

public enum DiasSemana {
	 LUNES, MARTES, MIÉRCOLES, JUEVES, VIERNES, SÁBADO, DOMINGO; 
}
