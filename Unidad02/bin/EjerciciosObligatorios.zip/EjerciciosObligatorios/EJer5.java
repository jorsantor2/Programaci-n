package EjerciciosObligatorios;

public class EJer5 {

	public static void main(String[] args) {
		
		System.out.println("Odio los  " + DiasSemana.LUNES);
		System.out.println("Los "+ DiasSemana.MARTES + " paso de la dase de negación a la fase de aceptación.");
		System.out.println("Cuando es " + DiasSemana.MIÉRCOLES + " pienso que ya vamos por la mitad de la semana.");
		System.out.println("El previo del Viernes, el " + DiasSemana.JUEVES + ", es mi día favorito de la semana.");
		System.out.println("El "+ DiasSemana.VIERNES + " suelo quedar con mis amigos para cenar." );
		System.out.println("Los " + DiasSemana.SÁBADO + " me levanto tarde y siempre desayuno tortitas");
		System.out.println("Me deprimen los " + DiasSemana.DOMINGO + " porque pienso que mañana es " + DiasSemana.LUNES);
		
	}

}
